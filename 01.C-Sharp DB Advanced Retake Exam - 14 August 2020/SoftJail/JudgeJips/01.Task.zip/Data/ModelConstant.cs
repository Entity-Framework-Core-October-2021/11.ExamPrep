﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SoftJail.Data
{
    public static class ModelConstant
    {
        public const int PRISONER_FULL_NAME_MIN_LENGTH = 3;
        public const int PRISONER_FULL_NAME_MAX_LENGTH = 20;

    }
}
